package com.example.jetdestinations

import androidx.compose.runtime.Composable
import androidx.navigation.NavController
import com.example.jetdestinations.data.DestinationRepository // Ensure this import is present
import com.example.jetdestinations.model.Destination

@Composable
fun DestinationDetailScreen(navController: NavController,  destination: Destination) {
    DestinationDetail(
        name = destination.name,
        photoUrl = destination.photoUrl,
        description = destination.description,
        navigateUp = { navController.popBackStack() }
    )
}