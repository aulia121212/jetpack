package com.example.jetdestinations.model

object DestinationsData {
    val destinations = listOf(
        Destination(
            "1",
            "Pura Besakih",
            "https://images.tokopedia.net/img/JFrBQq/2022/6/20/377b1745-2b01-42bb-a954-9604550daaa5.jpg"
        ),
        Destination(
            "2",
            "Kepulauan Derawan",
            "https://images.tokopedia.net/img/JFrBQq/2022/6/20/11879c35-5510-42b9-8bbf-b6f8943852aa.jpg"
        ),
        Destination(
            "3",
            "Taman Nasional Way Kambas",
            "https://images.tokopedia.net/img/JFrBQq/2022/6/20/7119654e-2bc3-48cb-a74e-5a7355863467.jpg"
        ),
        Destination(
            "4",
            "Pantai Parai Tenggiri (Bangka Belitung)",
            "https://images.tokopedia.net/blog-tokopedia-com/uploads/2020/06/Pantai-Parai-Tenggiri.jpg"
        ),
        Destination(
            "5",
            "Nusa Dua (Bali)",
            "https://images.tokopedia.net/blog-tokopedia-com/uploads/2020/06/Nusa-Dua-Bali.jpg"
        ),
        Destination(
            "6",
            "Gunung Rinjani (Lombok, NTB)",
            "https://images.tokopedia.net/blog-tokopedia-com/uploads/2020/06/gunung-rinjani.jpg"
        ),
        Destination(
            "7",
            "Danau Toba (Sumatera Utara)",
            "https://images.tokopedia.net/blog-tokopedia-com/uploads/2018/11/danau-toba.jpg"
        ),
        Destination(
            "8",
            "Nusa Penida (Bali)",
            "https://images.tokopedia.net/blog-tokopedia-com/uploads/2018/11/nusa-penida.jpg"
        ),
        Destination(
            "9",
            "Taman Laut Bunaken (Sulawesi Utara)",
            "https://images.tokopedia.net/img/JFrBQq/2022/10/13/e7147316-30dd-41ba-9abb-645d82e171af.jpg"
        ),
        Destination(
            "10",
            "Wakatobi (Sulawesi Tenggara)",
            "https://images.tokopedia.net/blog-tokopedia-com/uploads/2018/11/wakatobi.jpg"
        ),
        Destination(
            "11",
            "Kepulauan Raja Ampat (Papua Barat)",
            "https://images.tokopedia.net/blog-tokopedia-com/uploads/2018/11/raja-ampat.jpg"
        ),
        Destination(
            "12",
            "Gunung Bromo (Jawa Timur)",
            "https://images.tokopedia.net/blog-tokopedia-com/uploads/2018/11/gunung-bromo.jpg"
        ),
        Destination(
            "13",
            "Pulau Komodo (Nusa Tenggara Timur)",
            "https://images.tokopedia.net/blog-tokopedia-com/uploads/2018/11/pulau-komodo.jpg"
        ),
        Destination(
            "14",
            "Candi Borobudur (Jawa Tengah)",
            "https://images.tokopedia.net/blog-tokopedia-com/uploads/2018/11/candi-borobudur.jpg"
        ),
        Destination(
            "15",
            "Tana Toraja (Sulawesi Selatan)",
            "https://images.tokopedia.net/img/JFrBQq/2022/10/13/f4dc9653-34e9-4cfd-a8ea-699f3cbaeab2.jpg"
        ),
        Destination(
            "16",
            "Gili Trawangan (NTB)",
            "https://images.tokopedia.net/blog-tokopedia-com/uploads/2018/11/gili-trawangan.jpg"
        ),
        Destination(
            "17",
            "Goa Gong (Jawa Timur)",
            "https://images.tokopedia.net/blog-tokopedia-com/uploads/2018/11/goa-gong.jpg"
        ),
        Destination(
            "18",
            "Danau Kelimutu (NTT)",
            "https://images.tokopedia.net/blog-tokopedia-com/uploads/2018/11/danau-kelimutu.jpg"
        ),
        Destination(
            "19",
            "Ngarai Sianok (Sumatra Barat)",
            "https://images.tokopedia.net/blog-tokopedia-com/uploads/2018/11/Ngaraisianok.jpg"
        ),
        Destination(
            "20",
            "Kawah Ijen (Jawa Timur)",
            "https://images.tokopedia.net/blog-tokopedia-com/uploads/2018/11/kawah-ijen.jpg"
        ),
    )
}