package com.example.jetdestinations.data

import androidx.lifecycle.LiveData
import com.example.jetdestinations.model.Destination
import com.example.jetdestinations.model.DestinationsData
import kotlinx.coroutines.flow.MutableStateFlow

class DestinationRepository {
    fun getDestinations(): List<Destination> {
        return DestinationsData.destinations
    }

    fun searchDestinations(query: String): List<Destination>{
        return DestinationsData.destinations.filter {
            it.name.contains(query, ignoreCase = true)
        }
    }
}