package com.example.jetdestinations

import com.example.jetdestinations.data.DestinationRepository
import com.example.jetdestinations.model.Destination
import androidx.compose.runtime.State
import androidx.compose.runtime.mutableStateOf
import androidx.lifecycle.LiveData
import androidx.lifecycle.ViewModel
import androidx.lifecycle.ViewModelProvider
import androidx.lifecycle.viewModelScope
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.launch

class JetDestinationsViewModel(private val repository: DestinationRepository) : ViewModel() {
    private val _groupedDestinations = MutableStateFlow(
        repository.getDestinations()
            .sortedBy { it.name }
            .groupBy { it.name[0] }
    )
    val groupedDestinations: StateFlow<Map<Char, List<Destination>>> get() = _groupedDestinations

    private val _query = mutableStateOf("")
    val query: State<String> get() = _query

    fun search(newQuery: String) {
        _query.value = newQuery
        _groupedDestinations.value = repository.searchDestinations(_query.value)
            .sortedBy { it.name }
            .groupBy { it.name[0] }
    }
}

class ViewModelFactory(private val repository: DestinationRepository) :
    ViewModelProvider.NewInstanceFactory() {

    @Suppress("UNCHECKED_CAST")
    override fun <T : ViewModel> create(modelClass: Class<T>): T {
        if (modelClass.isAssignableFrom(JetDestinationsViewModel::class.java)) {
            return JetDestinationsViewModel(repository) as T
        }
        throw IllegalArgumentException("Unknown ViewModel class: " + modelClass.name)
    }
}