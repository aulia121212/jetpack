package com.example.jetdestinations.model

data class Destination(
    val id: String,
    val name: String,
    val photoUrl: String
)