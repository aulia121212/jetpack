package com.example.jetdestinations

import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.tooling.preview.Preview
import androidx.compose.ui.unit.dp
import androidx.navigation.NavController
import androidx.navigation.compose.rememberNavController
import coil.compose.rememberImagePainter
import coil.request.ImageRequest
import coil.transform.CircleCropTransformation

@Composable
fun UserProfile(navController: NavController) {
    // Replace with your user data
    val userName = "Aulia Azizah Ramadhanti"
    val userEmail = "10211022@student.itk.ac.id"
    val userProfileImageUrl = "https://drive.google.com/file/d/1IRk01vT-9sGv3-0wcL6APFJvprT67pRS/view?usp=sharing"

    val imageRequest = ImageRequest.Builder(LocalContext.current)
        .data(userProfileImageUrl)
        .transformations(CircleCropTransformation())
        .build()

    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(16.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.Center
    ) {
        // Tampilkan foto profil
        Image(
            painter = rememberImagePainter(request = imageRequest),
            contentDescription = "User Profile",
            modifier = Modifier
                .size(150.dp)
                .clip(shape = CircleShape)
                .background(MaterialTheme.colorScheme.primary)
        )
        // Tampilkan nama dan email
        Text(text = "Name: $userName", style = MaterialTheme.typography.titleLarge.copy(fontWeight = FontWeight.Bold))
        Text(text = "Email: $userEmail", style = MaterialTheme.typography.bodyMedium)
    }
}

@Preview(showBackground = true)
@Composable
fun UserProfilePreview() {
    UserProfile(navController = rememberNavController())
}



