package com.example.jetdestinations

import androidx.compose.runtime.Composable
import androidx.navigation.NavController
import com.example.jetdestinations.data.DestinationRepository // Ensure this import is present

@Composable
fun DestinationDetailScreen(navController: NavController, destinationId: String) {
    // Logika untuk mendapatkan detail destinasi berdasarkan destinationId
    val destination = DestinationRepository().getDestinationById(destinationId)

    // Tampilkan detail destinasi menggunakan composable DestinationDetail
    destination?.let {
        DestinationDetail(
            name = it.name,
            photoUrl = it.photoUrl,
            description = it.description,
            navigateUp = { navController.popBackStack() }
        )
    }
}