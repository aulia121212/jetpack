package com.example.jetdestinations.data

import com.example.jetdestinations.model.Destination
import com.example.jetdestinations.model.DestinationsData

class DestinationRepository {

    fun getDestinations(): List<Destination> {
        return DestinationsData.destinations
    }

    fun searchDestinations(query: String): List<Destination>{
        return DestinationsData.destinations.filter {
            it.name.contains(query, ignoreCase = true)
        }
    }

    fun getDestinationById(destinationId: String): Destination? {

        return DestinationsData.destinations.find { it.id == destinationId }
    }
}