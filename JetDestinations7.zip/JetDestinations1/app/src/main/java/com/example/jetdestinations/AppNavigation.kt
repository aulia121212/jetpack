package com.example.jetdestinations

import androidx.compose.animation.*
import androidx.compose.foundation.layout.*
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.runtime.*
import androidx.navigation.NavType
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.rememberNavController
import androidx.navigation.navArgument
import com.example.jetdestinations.data.DestinationRepository

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun AppNavigation() {
    val navController = rememberNavController()
    val destinationRepository = DestinationRepository()
    NavHost(
        navController = navController,
        startDestination = "home"
    ) {
        composable("home") {
            JetDestinationsApp(navController = navController)
        }
        composable(
            "destinationDetail/{destinationId}",
            arguments = listOf(navArgument("destinationId") { type = NavType.StringType })
        ) { backStackEntry ->
            val destinationId = backStackEntry.arguments?.getString("destinationId")
            if (destinationId != null) {
                val destination = destinationRepository.getDestinationById(destinationId)
                DestinationDetailScreen(navController, destination)
            }
        }
        composable("profile") {
            UserProfile(navController = navController)
        }
    }
}


