package com.example.jetdestinations.model

object DestinationsData {
    val destinations = listOf(
        Destination(
            "1",
            "Pura Besakih",
            "https://images.tokopedia.net/img/JFrBQq/2022/6/20/377b1745-2b01-42bb-a954-9604550daaa5.jpg",
            "Pura Agung Besakih adalah pura terbesar dan termegah di Bali. Pulau ini terletak di Desa Besakih, Kecamatan Rendang, berada di lereng sebelah barat daya Gunung Agung, gunung tertinggi di Bali.\n" +
                    "\n" +
                    "Pura Agung Besakih memiliki gaya arsitektur yang mengagumkan khas Bali dan berada di ketinggian 915 kaki di kaki Gunung Agung dengan memukau. Bangunan yang dibangun sejak abad ke-10 Masehi ini menjadi pusat kegiatan spiritual Hindu Dharma di Pulau Dewata.\n" +
                    "\n" +
                    "Dengan segala fitur yang dimiliki Pura Besakih, tidak aneh jika situs ini ditetapkan sebagai Situs Warisan Budaya UNESCO sejak selamat dari erupsi Gunung Agung pada tahun 1963.\n" +
                    "\n" +
                    "Akses dari Kota Denpasar untuk mencapai tempat ini berjarak sekitar 25 km ke arah utara dari Kota Semarapura, Kabupaten Klungkung. Perjalanan menuju Pura Besakih melewati panorama Bukit Jambul yang juga merupakan salah satu obyek dan daya tarik wisata Kabupaten Karangasem."
        ),
        Destination(
            "2",
            "Kepulauan Derawan",
            "https://images.tokopedia.net/img/JFrBQq/2022/6/20/11879c35-5510-42b9-8bbf-b6f8943852aa.jpg",
            "Kepulauan Derawan adalah sebuah kepulauan yang berada di Kabupaten Berau, Kalimantan Timur. Di kepulauan ini terdapat sejumlah objek wisata bahari menawan, salah satunya Taman Bawah Laut yang diminati wisatawan mancanegara terutama para penyelam kelas dunia.\n" +
                    "\n" +
                    "Saat pertama kali menginjakan kaki disini, jangan heran bila Toppers akan disambut dengan hamparan pasir putih yang mempesona. Warna airnya yang sangat jernih juga akan bikin kamu betah untuk berlama-lama di kawasan ini. Panorama alam ini menjadi sajian liburan utama bagi wisatawan dalam berkunjung\n" +
                    "\n" +
                    "Faktor lain yang menjadi alasan mengapa kawasan ini wajib untuk dikunjungi, yaitu ekosistem bawah laut dan keasrian alam sekitarnya benar-benar masih sangat terjaga. Wajar jika banyak wisatawan yang datang berbondong-bondong ke tempat ini, baik wisatawan lokal maupun wisatawan internasional.\n" +
                    "\n" +
                    "Pada tahun 2005 pemerintah telah mencoba mendaftarkan kawasan wisata ini ke UNESCO sebagai salah satu situs warisan dunia, bahkan sampai mendapat julukan sebagai “Pristine Island”."
        ),
        Destination(
            "3",
            "Taman Nasional Way Kambas",
            "https://images.tokopedia.net/img/JFrBQq/2022/6/20/7119654e-2bc3-48cb-a74e-5a7355863467.jpg",
            "Taman Nasional Way Kambas (TNKW) Lampung ditetapkan sebagai kawasan Taman Warisan ASEAN (ASEAN Heritage Park) yang ke-36, pada tanggal 25 Juli 2016. Artinya, Taman Nasional Way Kambas ini menjadi Taman Warisan ASEAN ke-4 di Indonesia.\n" +
                    "\n" +
                    "Terletak di ujung selatan Sumatera atau 110 km dari Bandar Lampung, TNKW merupakan salah satu Taman Nasional pertama dan tertua di Indonesia. Taman Nasional ini menempati 1.300 km persegi dari hutan dataran rendah pantai sekitar Sungai Way Kambas di pantai timur Provinsi Lampung.\n" +
                    "\n" +
                    "TNWK dikenal dengan konservasi gajah, karena selain menjadi tempat perlindungan bagi Gajah Sumatera yang berjumlah sekitar 200, taman nasional ini juga dikenal sebagai tempat latihan mereka. Way Kambas didirikan oleh pemerintah Belanda pada tahun 1937 sampai sekarang masih terjaga sebagai Taman Nasional.\n" +
                    "\n" +
                    "Selain konservasi gajah, di sini juga terdapat konservasi badak sumatera dan ada fasilitas Rhino Sanctuary. Sayangnya untuk bisa dapat melihat Badak Sumatera ini, pengunjung harus punya izin khusus sebelumnya. Pengunjung atau wisatawan biasa tidak bisa melihat penangkaran alami badak sumatera ini."
        ),
        Destination(
            "4",
            "Pantai Parai Tenggiri (Bangka Belitung)",
            "https://images.tokopedia.net/blog-tokopedia-com/uploads/2020/06/Pantai-Parai-Tenggiri.jpg",
            "Pasti diantara kamu sudah pernah menyaksikan film populer Laskar Pelangi yang berlatar di Pulang Belitung, bukan? Selain alur ceritanya yang menarik, lokasi film ini juga banyak menyita perhatian penonton. \n" +
                    "\n" +
                    "Berbeda dengan pantai lain pada umumnya, Parai Tenggiri memiliki struktur pantai yang landai dengan air laut berwarna hijau toska serta pasir putihnya yang lembut. Ombak di pantai ini juga tenang sehingga menjadi salah satu alasan yang menarik bagi wisatawan yang senang berenang. \n" +
                    "\n" +
                    "Tidak hanya berenang, kamu juga bisa menikmati aktivitas memancing, parasailing, menyelam, snorkeling, dan masih banyak lainnya."
        ),
        Destination(
            "5",
            "Nusa Dua (Bali)",
            "https://images.tokopedia.net/blog-tokopedia-com/uploads/2020/06/Nusa-Dua-Bali.jpg",
            "Pulau Seribu Dewa satu ini memang tidak perlu diragukan lagi terkait keindahan dan pesonanya dalam memikat para wisatawan dalam negeri maupun mancanegara. Di Bali, ada satu tempat wisata yang begitu cantik, yakni Nusa Dua. \n" +
                    "\n" +
                    "Objek wisata pantai ini memiliki pasir putih yang lembut dan air laut yang berwarna biru jernih. Kamu akan dimanjakan dengan berbagai fasilitas saat berkunjung ke tempat satu ini. Mulai dari penginapan dan resort yang berkelas, restoran, pusat perbelanjaan, hingga aktivitas berselancar di pantainya."
        ),
        Destination(
            "6",
            "Gunung Rinjani (Lombok, NTB)",
            "https://images.tokopedia.net/blog-tokopedia-com/uploads/2020/06/gunung-rinjani.jpg",
            "Selain Gili Trawangan, di Nusa Tenggara Barat juga terdapat wisata yang tak kalah populer dan cocok bagi kamu yang suka mendaki, yakni Gunung Rinjani. Gunung ini adalah gunung berapi tertinggi kedua yang ada di Indonesia. \n" +
                    "\n" +
                    "Gunung Rinjani memiliki pemandangan terindah se-Asia dengan hamparan bunga edelweis dan Danau Segara Anak. Di tempat ini juga bisa menjadi spot menarik bagi para pendaki untuk mendirikan tenda, mandi air hangat, maupun memancing ikan. \n" +
                    "\n" +
                    "Namun sebelum itu, buatlah persiapan yang matang sebelum memutuskan untuk mendaki. Kamu juga perlu menyiapkan bekal mental dan stamina agar tidak menyerah di tengah jalan."
        ),
        Destination(
            "7",
            "Danau Toba (Sumatera Utara)",
            "https://images.tokopedia.net/blog-tokopedia-com/uploads/2018/11/danau-toba.jpg",
            "Toppers pernah berkunjung ke Danau Toba? Danau dengan keindahan yang tidak tertandingi ini merupakan danau vulkanik terbesar di Asia Tenggara dan terbesar kedua di dunia setelah Danau Victoria.\n" +
                    "\n" +
                    "Danau Toba sudah lama terkenal sebagai salah satu objek wisata Indonesia favorit yang sering dikunjungi sejak tahun 1980-an lho!\n" +
                    "\n" +
                    "Objek wisata Indonesia yang terkenal di dunia ini memiliki luas 1.145 kilometer persegi. Di tengah danau terdapat Pulau Samosir yang luasnya hampir sebanding dengan negara Singapura. Bisa bayangin kan Toppers, betapa megahnya Danau Toba ini?\n" +
                    "\n" +
                    "Selain terluas, danau ini juga termasuk salah satu danau terdalam di dunia dengan kedalaman sekitar 450 meter.\n" +
                    "\n" +
                    "Buat Toppers yang sedang atau ingin berkunjung ke Sumatera Utara, sempatkan mampir untuk menikmati keindahan Danau Toba, ya."
        ),
        Destination(
            "8",
            "Nusa Penida (Bali)",
            "https://images.tokopedia.net/blog-tokopedia-com/uploads/2018/11/nusa-penida.jpg",
            "Pulau Bali, sudah tidak bisa dipungkiri lagi namanya memang merajalela ke seluruh dunia karena pemandangannya yang indah, budayanya yang masih kental terasa dan pantai nya yang eksotis.\n" +
                    "\n" +
                    "Saat Toppers berkunjung ke Bali jangan heran kalau banyak banget turis berlalu lalang di sana, bahkan beberapa ada yang menetap di Bali lho!\n" +
                    "\n" +
                    "Salah satu objek wisata di Bali yang populer di mata dunia saat ini adalah Nusa Penida. Tempat wisata Indonesia favorit ini adalah pilihan tepat untuk Toppers yang suka melakukan Island Hoping, dan menikmati keindahan bawah laut dengan snorkeling.\n" +
                    "\n" +
                    "Dengan panorama pantai yang indah Nusa Penida dan pulau-pulau kecil sekitarnya menawarkan pengalaman berbeda dan tentunya akan memanjakan Toppers yang juga memiliki hobi fotografi."
        ),
        Destination(
            "9",
            "Taman Laut Bunaken (Sulawesi Utara)",
            "https://images.tokopedia.net/img/JFrBQq/2022/10/13/e7147316-30dd-41ba-9abb-645d82e171af.jpg",
            "Destinasi wisata di Indonesia yang populer di mancanegara selanjutnya adalah Taman Laut Bunaken yang berada di Teluk Manado.\n" +
                    "\n" +
                    "Bunaken menjadi salah satu objek wisata di Indonesia yang mengundang decak kagum karena keindahan taman bawah lautnya yang sulit ditemukan di negara lain.\n" +
                    "\n" +
                    "Berkunjung ke Taman Laut Bunaken, Toppers akan menemukan keindahan kehidupan di dalam laut yang membuat mata kamu tidak bisa berhenti memandangnya.\n" +
                    "\n" +
                    "Di dalam taman laut ini terdapat 13 jenis terumbu karang yang didominasi dengan bebatuan laut.\n" +
                    "\n" +
                    "Selain itu, pemandangan yang paling menarik adalah adanya terumbu karang terjal vertikal yang menjulang ke bawah sedalam 25 – 50 meter. Tidak sampai di situ, mata kita akan dimanjakan dengan 91 jenis ikan yang ada di dalamnya.\n" +
                    "\n" +
                    "Tidak heran kalau Taman Laut Bunaken menjadi salah satu destinasi bagi para wisatawan terutama para pecinta laut.\n" +
                    "\n" +
                    "Apalagi tujuan wisata Indonesia favorit wisatawan asing ini menyediakan fasilitas untuk scuba diving dengan 20 titik penyelaman terbaik, di mana penyelam dapat kesempatan berenang di dasar laut dengan beragam biota laut yang menakjubkan."
        ),
        Destination(
            "10",
            "Wakatobi (Sulawesi Tenggara)",
            "https://images.tokopedia.net/blog-tokopedia-com/uploads/2018/11/wakatobi.jpg",
            "Masih di Pulau Sulawesi, Taman Nasional Wakatobi juga merupakan salah satu tujuan wisata bawah laut yang populer dan mendunia.\n" +
                    "\n" +
                    "Dengan luas mencapai 13.900 km2, tujuan wisata terkenal asal Indonesia ini memiliki tak kurang dari 112 jenis terumbu karang yang bersimbiosis dengan ikan-ikan bawah laut sehingga menciptakan panorama bawah laut yang tiada tanding.\n" +
                    "\n" +
                    "Semuanya itu menjadikan Wakatobi sebagai salah satu surga menyelam bagi para traveler dari berbagai penjuru dunia."
        ),
        Destination(
            "11",
            "Kepulauan Raja Ampat (Papua Barat)",
            "https://images.tokopedia.net/blog-tokopedia-com/uploads/2018/11/raja-ampat.jpg",
            "Surga dunia di Indonesia selanjutnya adalah kepulauan Raja Ampat yang terletak di Papua Barat dengan kekayaan laut terlengkap di bumi.\n" +
                    "\n" +
                    "Raja Ampat atau Empat Raja merupakan 4 pulau indah yang merupakan penghasil lukisan batu kuno. Empat pulau utama yang dimaksud adalah Waigeo, Salawati, Batanta, dan Misool.\n" +
                    "\n" +
                    "Nama-nama tersebut berasal dari mitos lokal dari warga di sekitar pulau Raja Ampat. Keindahan dan kemegahan dari objek wisata populer asal Indonesia ini mampu mengundang para wisatawan dari seluruh dunia untuk datang ke sini dan merasakan pengalaman sekaligus pemandangan yang tidak akan terlupakan.\n" +
                    "\n" +
                    "Dengan wilayah pulau mencakup hingga 4,6 juta hektar tanah dan laut, kita bisa menemukan 540 jenis karang, 1.511 spesies ikan, serta 700 jenis moluska.\n" +
                    "\n" +
                    "Perlu diketahui Toppers, menurut laporan The Nature Conservancy and Conservation International, ada sekitar 75% spesies laut dunia yang tinggal di pulau indah nan menakjubkan ini."
        ),
        Destination(
            "12",
            "Gunung Bromo (Jawa Timur)",
            "https://images.tokopedia.net/blog-tokopedia-com/uploads/2018/11/gunung-bromo.jpg",
            "Kalau kamu pernah berkunjung ke Jawa Timur gak lengkap rasanya kalau belum menginjakkan kaki ke Gunung Bromo ini.\n" +
                    "\n" +
                    "Salah satu gunung berapi yang masih aktif ini memiliki pesona khas berupa gurun pasir yang sangat luat.\n" +
                    "\n" +
                    "Meskipun bukan salah satu gunung tertinggi di Indonesia, namun keindahan Gunung Bromo tidak ada duanya dan membuat para pengunjung dapat merasakan pemandangan yang fantastis dan spektakuler.\n" +
                    "\n" +
                    "Wisatawan dapat berkuda dan mendaki gunung bromo untuk menikmati keindahan yang menawan saat matahari terbit dan terbenam.\n" +
                    "\n" +
                    "Bisa jadi pengalaman secara langsung yang tidak terlupakan lho Toppers! Dengan keindahan yang menakjubkan itu tidak heran jika objek wisata di Indonesia satu ini menjadi para wisatawan mancanegara yang berkunjung ke Indonesia."
        ),
        Destination(
            "13",
            "Pulau Komodo (Nusa Tenggara Timur)",
            "https://images.tokopedia.net/blog-tokopedia-com/uploads/2018/11/pulau-komodo.jpg",
            "Destinasi wisata Indonesia yang tersohor di mata dunia selanjutnya adalah Pulau Komodo. Pulau yang berlokasi di Kepulauan Nusa Tenggara Timur ini merupakan rumah bagi ratusan Komodo, hewan endemik yang hanya ada di Indonesia.\n" +
                    "\n" +
                    "Selain bisa mengamati perilaku dan mengeksplorasi habitat dari hewan purba ini, Pulau Komodo juga menawarkan panorama alam yang menakjubkan.\n" +
                    "\n" +
                    "Salah satunya adalah pantai dengan pasir berwarna merah muda yang dikenal dengan nama “Pink Beach“.\n" +
                    "\n" +
                    "Pantai seperti ini hanya terdapat tujuh di seluruh dunia sehingga menjadikannya sebagai salah satu tujuan wisata Indonesia yang mendunia."
        ),
        Destination(
            "14",
            "Candi Borobudur (Jawa Tengah)",
            "https://images.tokopedia.net/blog-tokopedia-com/uploads/2018/11/candi-borobudur.jpg",
            "Salah satu ikon wisata budaya Indonesia yang mendunia lainnya adalah Candi Borobudur. Sebagai candi Budha terbesar di dunia dengan luas tak kurang dari 123 X 123 meter, candi yang dibangun pada masa kerajaan Mataram kuno ini merupakan warisan budaya dan sejarah Indonesia yang terkenal akan arsitektur yang memukau.\n" +
                    "\n" +
                    "Setiap tahunnya, tak cuma wisatawan domestik tetapi banyak juga wisatawan asing yang tertarik untuk mengamati keindahan dari Candi Borobudur.\n" +
                    "\n" +
                    "Berbagai relief yang menceritakan mengenai berbagai ajaran dalam agama Budha dan perjalanan hidup Sidharta Gautama hingga mencapai pencerahan sempurna bisa Toppers temukan di tempat wisata favorit asal Indonesia.\n" +
                    "\n" +
                    "Candi Borobudur sendiri memiliki total tak kurang dari 504 arca Buddha dan 2.672 panel relief pada dinding-dindingnya. Menakjubkan sekali, bukan?"
        ),
        Destination(
            "15",
            "Tana Toraja (Sulawesi Selatan)",
            "https://images.tokopedia.net/img/JFrBQq/2022/10/13/f4dc9653-34e9-4cfd-a8ea-699f3cbaeab2.jpg",
            "Indonesia memang kaya akan adat dan budaya yang menarik mata dunia. Salah satu destinasi wisata Indonesia yang terkenal akan kekayaan tradisi budayanya adalah  Kabupaten Tana Toraja.\n" +
                    "\n" +
                    "Terletak di Sulawesi Selatan dikawasan pegunungan yang indah, Toppers masih bisa melihat uniknya keseharian dan tradisi masyarakat adat Tana Toraja.\n" +
                    "\n" +
                    "Selain keindahan arsitektur tradisional rumah tongkonan, wisatawan juga bisa mengamati tradisi unik upacara kematian yang dikenal sebagai Rambu Solo yang biasanya diselenggarakan pada Juli dan Agustus\n" +
                    "\n" +
                    "Keunikan dari tradisi ini menjadikan Tana Toraja sebagai tempat wisata asal Indonesia yang memiliki daya tarik mendunia."
        ),
        Destination(
            "16",
            "Gili Trawangan (NTB)",
            "https://images.tokopedia.net/blog-tokopedia-com/uploads/2018/11/gili-trawangan.jpg",
            "Untuk pecinta pantai, Gili Trawangan merupakan tujuan wisatawan dari seluruh dunia. Dengan kombinasi langit biru dengan semburat awan putih, jernihnya air laut dibingkai pasir putih menjadikan Gili Trawangan sebagai tujuan wisata populer baik bagi wisatawan dalam negeri maupun luar negeri.\n" +
                    "\n" +
                    "Selain pantai dan alam bawah laut, tempat wisata Nusantara yang berada di Provinsi Nusa Tenggara Barat ini juga memiliki berbagai lansekap menakjubkan dan juga spot-spot foto yang instagramable, lho."
        ),
        Destination(
            "17",
            "Goa Gong (Jawa Timur)",
            "https://images.tokopedia.net/blog-tokopedia-com/uploads/2018/11/goa-gong.jpg",
            "Tujuan wisata Indonesia yang mendunia selanjutnya adalah Goa Gong yang terletak di Pacitan, Jawa Timur.\n" +
                    "\n" +
                    "Panorama eksotik yang ditawarkan oleh objek wisata alam Indoneisa ini disebut-sebut sebagai salah satu goa terindah di Asia Tenggara.\n" +
                    "\n" +
                    "Bertualang di Goa Gong, Toppers akan disuguhkan keeksotisan struktur stalaktit dan stalakmit yang terbentuk secara alami di Goa ini.\n" +
                    "\n" +
                    "Meskipun tidak sepopuler tempat wisata Indonesia lainnya, Goa Gong merupakan destinasi wisata favorit bagi para traveler dunia yang berjiwa petualang."
        ),
        Destination(
            "18",
            "Danau Kelimutu (NTT)",
            "https://images.tokopedia.net/blog-tokopedia-com/uploads/2018/11/danau-kelimutu.jpg",
            "Selain Danau Toba, destinasi wisata danau milik Indonesia yang mendunia adalah Danau Kelimutu. Danau ini merupakan danau vulkanik yang berada di puncak Gunung Kelimutu. Untuk mencapai danau indah ini, Toppers harus melakukan hiking terlebih dahulu.\n" +
                    "\n" +
                    "Keistimewaan danau yang terletak di Pulau Flores, NTT ini adalah pemandangan danau dengan tiga warna yakni hijau, putih dan biru. Setiap tahun, danau eksotik ini selalu ramai dikunjungi wisatawan mancanegara."
        ),
        Destination(
            "19",
            "Ngarai Sianok (Sumatra Barat)",
            "https://images.tokopedia.net/blog-tokopedia-com/uploads/2018/11/Ngaraisianok.jpg",
            "Ngarai Sianok yang terletak di perbatasan Kota Bukittinggi, Kabupaten Agam, Sumatra Barat ini terkenal akan keindahannya yang mendunia.\n" +
                    "\n" +
                    "Jurang yang membentang sepanjang 15 kilometer dengan kedalaman lebih dari 100 meter ini membentuk patahan alam yang indah tiada duanya. Terlebih di tengah patahan tersebut mengalir Sungai Batang Sianok yang mengairi alam lembah nan hijau dan permai."
        ),
        Destination(
            "20",
            "Kawah Ijen (Jawa Timur)",
            "https://images.tokopedia.net/blog-tokopedia-com/uploads/2018/11/kawah-ijen.jpg",
            "Dari Banyuwangi, terdapat pesona kawah Ijen yang baru-baru ini mulai terkenal sampai ke mancanegara. Salah satu daya pikatnya adalah blue fire atau pesona api biru yang menyala dari kawah Gunung Ijen." +
                    "Di dunia, fenomena blue fire hanya dapat ditemukan di dua tempat yakni di Islandia dan di Indonesia."
        ),
    )
}